// ============================================================================
// RMIS — shared job display helpers.
// Single source for the posting-place / publish-date read used by every job
// surface (public landing, applicant job cards, staff boards). Previously
// copy-pasted in public-landing.tsx and jobs/job-openings-card.tsx.
// ============================================================================

import type { JobWire } from "@/lib/router";

/** Agency address shown when a posting has no place of assignment. */
export const PLACE_FALLBACK = "DOST Compound, Taguig";

/** Display place — nested position read, then the agency address. */
export function jobPlace(job: JobWire): string {
  return job.position?.placeOfAssignment ?? PLACE_FALLBACK;
}

/** Posting age source — editorial publish date, else the record timestamp. */
export function postedAt(job: JobWire): string {
  return job.publishDate ?? job.publishedAt;
}
