"use client";

// ============================================================================
// RMIS — Profile builder · Section 07 Supporting Documents (spec §7.4, §10).
// Storage-only by design (no extraction here). A category is REQUIRED before
// any upload; multi-file batch upload posts sequentially with per-file
// toasts; rows show name / size / category / date (+ status pill for
// extractable categories, extraction error via tooltip) with single and
// checkbox batch delete.
// Rows are clickable: the name/chip area (or the eye button) opens a preview
// modal — PDFs render inline in an iframe, images in an <img>, Word/Excel
// fall back to a download card. Checkbox and delete stay independent.
// Upload surface: the OFFICIAL BEUI FileUpload block (variant="default",
// multiple) — queue rows persist as a session log (removable via each row's
// X) and per-row status/error mirror the real POST results (no invented
// progress). The category gate stays as glue (the block has no category
// concept): its own browse control opens the picker BEFORE the gate can run
// (the old button gated the picker itself), so a gateless batch is rejected
// after the fact by clearing the committed queue — same toast. Task 31-b:
// the category gate now runs the system-wide shake-red contract (the same
// effect as the sign-in/sign-up forms) via entry-form's shared ShakeField —
// shake + destructive ring + animated inline message, re-armed on every
// repeat trip (clear → 60 ms → re-apply). Size/MIME limits stay
// server-enforced (10 MB → 413, allowlist → 415 surface verbatim via
// per-file toasts), as before.
// Task 33 — the upload rail wears the OFFICIAL SignUpForm card anatomy
// (rounded-3xl bordered, cloud/60 surface preserved) and the category
// control moves onto the official field tokens (h-11, border-border,
// transparent bg, destructive ring) via ./beui-form — same family as the
// sign-in/sign-up fields.
// Bevel pass: local white section panel, cloud/60 tiles, StatusPill document
// statuses, .num metrics, functional --bad destructive styling. All behavior
// unchanged.
// ============================================================================

import { useEffect, useRef, useState } from "react";
import { toast } from "@/lib/toast";
import { Eye, FileText, Paperclip, Trash2 } from "lucide-react";
import { DocumentPreviewModal, documentStatusChip, fileKind } from "@/components/ui/document-preview";
import { FileUpload, type FileUploadItem } from "@/components/motion/file-upload";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/motion/select";
import { EmptyState, SectionCard, StatusPill } from "@/components/ui/shell";
import { ghostBadBtn, iconBtnBad, cancelBtn } from "@/components/ui/buttons";
import { Tooltip, TooltipProvider } from "@/components/motion/tooltip";
import { apiFetch, formatDate, humanize } from "@/lib/client";
import { cn } from "@/lib/utils";
import {
  BEUI_FIELD_LABEL,
  BEUI_TRIGGER_BASE,
  BEUI_TRIGGER_ERROR,
} from "./beui-form";
import { ShakeField } from "./entry-form";
import { DOCUMENT_CATEGORIES, EXTRACTABLE_CATEGORIES } from "@/lib/validation";
import type { DocumentWire } from "@/lib/router";
import { SaveHint, useSavedFlash } from "./save-hint";

const CATEGORY_NONE = "__select__";
const EXTRACTABLE = EXTRACTABLE_CATEGORIES as readonly string[];

export default function DocumentsSection({
  docs,
  onChanged,
}: {
  docs: DocumentWire[];
  onChanged: () => void | Promise<void>;
}) {
  const [category, setCategory] = useState("");
  const [categoryError, setCategoryError] = useState(false);
  // Shake re-arm timer — the ShakeField wrapper animates on a false→true
  // error flip, so a repeat gate trip with the category STILL missing must
  // clear first, then re-apply 60 ms later (the shared re-arm dance).
  const categoryRearmRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(
    () => () => {
      if (categoryRearmRef.current) clearTimeout(categoryRearmRef.current);
    },
    []
  );
  const flagCategoryError = () => {
    setCategoryError(false);
    if (categoryRearmRef.current) clearTimeout(categoryRearmRef.current);
    categoryRearmRef.current = setTimeout(() => setCategoryError(true), 60);
  };
  // Official BEUI FileUpload queue — a session log of this visit's uploads.
  const [queue, setQueue] = useState<FileUploadItem[]>([]);
  // Active POST counter (not a boolean): a single-file retry overlapping a
  // running batch must not drop the SaveHint early.
  const [activeUploads, setActiveUploads] = useState(0);
  const uploading = activeUploads > 0;
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [deleteTargets, setDeleteTargets] = useState<string[] | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [preview, setPreview] = useState<DocumentWire | null>(null);
  const [savedFlash, flashSaved] = useSavedFlash();

  const openPreview = (doc: DocumentWire) => setPreview(doc);

  /** Patch one queue row — real API results only (no invented progress). */
  const patchItem = (id: string, patch: Partial<FileUploadItem>) => {
    setQueue((prev) => prev.map((it) => (it.id === id ? { ...it, ...patch } : it)));
  };

  /** One sequential POST — the exact old API contract (FormData file +
      category, same endpoint). Resolves true on success; failure marks the
      row "error" with the server message (same toast copy as before). */
  const postOne = async (item: FileUploadItem): Promise<boolean> => {
    try {
      if (!item.file) throw new Error(`${item.name} could not be uploaded`);
      const fd = new FormData();
      fd.append("file", item.file);
      fd.append("category", category);
      await apiFetch("/api/applicant/documents", { method: "POST", formData: fd });
      toast.success(`${item.name} uploaded`);
      patchItem(item.id, { status: "success" });
      return true;
    } catch (e) {
      const message = e instanceof Error ? e.message : `${item.name} could not be uploaded`;
      toast.error(message);
      patchItem(item.id, { status: "error", error: message });
      return false;
    }
  };

  /** Sequential per-file POSTs, in order — shared by the batch upload AND a
      single-file retry (a retry is a one-item batch under the CURRENT
      category); okCount still gates the saved flash + parent refresh. */
  const runUploads = async (batch: FileUploadItem[]) => {
    setActiveUploads((n) => n + 1);
    let okCount = 0;
    for (const item of batch) {
      if (await postOne(item)) okCount += 1;
    }
    setActiveUploads((n) => Math.max(0, n - 1));
    if (okCount > 0) {
      flashSaved();
      await onChanged();
    }
  };

  /** The block commits the batch (status "uploading") BEFORE calling us.
      Category gate — glue (the block has no category concept). DELTA vs the
      old UI: the block's own browse control opens the picker BEFORE this
      gate can run (the old button gated the picker itself), so the batch is
      rejected here by clearing the committed queue — the rejection surface
      (shake + red ring + animated message + toast) is identical. */
  const handleFilesAdded = (added: FileUploadItem[]) => {
    if (!category) {
      setQueue([]);
      flagCategoryError();
      toast.error("Select a category before uploading");
      return;
    }
    setCategoryError(false);
    void runUploads(added);
  };

  /** Row retry: the block pre-flipped the row to "uploading" (error cleared,
      progress 0) before calling us — re-POST that single file (the official
      item carries its File) under the CURRENT category. */
  const handleRetry = (item: FileUploadItem) => {
    void runUploads([item]);
  };

  const runDelete = async (ids: string[]) => {
    setDeleting(true);
    let okCount = 0;
    for (const id of ids) {
      try {
        await apiFetch(`/api/applicant/documents/${id}`, { method: "DELETE" });
        okCount += 1;
      } catch (e) {
        toast.error(e instanceof Error ? e.message : "A document could not be deleted");
      }
    }
    setDeleting(false);
    setDeleteTargets(null);
    setSelected(new Set());
    if (okCount > 0) {
      toast.success(okCount === 1 ? "Document deleted" : `${okCount} documents deleted`);
      await onChanged();
    }
  };

  const toggle = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  return (
    <SectionCard
      variant="plain"
      icon={FileText}
      chipTone="slate"
      title="Supporting Documents"
      description="Credentials for HR verification: stored as-is. PDS extraction lives at the top of this page."
      actions={<SaveHint saving={uploading} saved={savedFlash} />}
    >
      {/* Upload rail — category REQUIRED before any file is accepted (§7.4);
          the gate itself runs in handleFilesAdded (delta note there). The
          rail is a SignUpForm-shaped card (Task 33): rounded-3xl bordered,
          cloud/60 surface preserved. */}
      <div className="rounded-3xl border border-border bg-cloud/60 p-4">
        {/* items-center: the official dropzone is taller than the old button. */}
        <div className="grid gap-3 sm:grid-cols-[minmax(0,220px)_minmax(0,1fr)] sm:items-center">
          <div>
            <p className={BEUI_FIELD_LABEL}>
              Category<span className="text-dusty-rose"> *</span>
            </p>
            {/* Shake-red contract (Task 31-b): ShakeField shakes + animates the
                "Choose a category first." line on every false→true flip; the
                ring is the official field error token (Task 33) — the same
                anatomy as the entry-form selects in sections 02–06.
                Selecting a category clears the error immediately (reward
                early). */}
            <ShakeField error={categoryError ? "Choose a category first." : undefined}>
              <Select
                className="w-full"
                value={category !== "" ? category : CATEGORY_NONE}
                onValueChange={(v) => {
                  setCategory(v === CATEGORY_NONE ? "" : v);
                  setCategoryError(false);
                }}
                disabled={uploading}
              >
                <SelectTrigger
                  className={cn(BEUI_TRIGGER_BASE, categoryError && BEUI_TRIGGER_ERROR)}
                >
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {DOCUMENT_CATEGORIES.map((c) => (
                    <SelectItem key={c} value={c}>
                      {humanize(c)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </ShakeField>
          </div>
          {/* Official BEUI FileUpload — no accept/maxFiles/maxFileSize: the
              old UI had none client-side (server-enforced 413/415), and the
              block exposes no onFilesRejected to wire. disabled preserves
              the old gate (no new picks while a batch runs). */}
          <FileUpload
            variant="default"
            multiple
            title="Choose files to upload"
            disabled={uploading}
            value={queue}
            onValueChange={setQueue}
            onFilesAdded={handleFilesAdded}
            onRetry={handleRetry}
          />
        </div>
      </div>

      {/* Batch action bar */}
      {selected.size > 0 && (
        <div className="mt-4 flex items-center justify-between rounded-lg bg-cloud/60 px-4 py-2">
          <span className="num text-xs text-stone">{selected.size} selected</span>
          <button
            type="button"
            onClick={() => setDeleteTargets([...selected])}
            disabled={deleting}
            className="focus-ring inline-flex min-h-[44px] items-center gap-2 px-4 text-sm font-medium text-[var(--bad)] disabled:opacity-50"
          >
            <Trash2 className="h-4 w-4" /> Delete selected
          </button>
        </div>
      )}

      {/* File rows */}
      {docs.length === 0 ? (
        <EmptyState compact icon={Paperclip} tone="slate" title="No documents on file yet" description="Upload credentials HR will need for verification." className="mt-4" />
      ) : (
        <TooltipProvider delay={150}>
          {/* No inner max-height below lg: the section column is already a
              bounded scroller — a nested scroll pane traps touch gestures
              on phones. The cap returns on lg where the column is roomy. */}
          <div className="mt-4 space-y-2 overflow-y-auto scroll-thin pr-1 lg:max-h-96">
            {docs.map((doc) => {
              const chip = documentStatusChip(doc);
              return (
                <div
                  key={doc.id}
                  className="flex items-center gap-3 rounded-lg bg-cloud/60 px-3 py-2.5 transition-colors hover:bg-cloud"
                >
                  <Checkbox
                    checked={selected.has(doc.id)}
                    onCheckedChange={() => toggle(doc.id)}
                    onClick={(e) => e.stopPropagation()}
                    aria-label={`Select ${doc.originalName}`}
                    className="shrink-0"
                  />
                  {/* Clickable view target: chip + name/meta open the preview modal. */}
                  <button
                    type="button"
                    onClick={() => openPreview(doc)}
                    className="group flex min-w-0 flex-1 cursor-pointer items-center gap-3 rounded-md text-left focus-ring"
                    aria-label={`View ${doc.originalName}`}
                  >
                    <span className="chip chip-slate h-6 shrink-0 px-2 text-[10px] font-medium tracking-wide" aria-hidden="true">
                      {fileKind(doc.originalName)}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p
                        className="truncate text-sm font-medium text-ink transition-colors group-hover:text-primary group-focus-visible:text-primary"
                        title={doc.originalName}
                      >
                        {doc.originalName}
                      </p>
                      <p className="num text-xs text-stone">
                        {humanize(doc.category)} · {Math.max(1, Math.round(doc.size / 1024))} KB · {formatDate(doc.createdAt)}
                      </p>
                    </div>
                  </button>
                  {chip && (
                    <Tooltip content={doc.extractionError} arrow>
                      <span className="inline-flex shrink-0 cursor-default">
                        <StatusPill status={chip.label} variant={chip.variant} className="shrink-0 cursor-default" />
                      </span>
                    </Tooltip>
                  )}
                  {/* Eye button: white hover on cloud/60 rows. */}
                  <button
                    type="button"
                    onClick={() => openPreview(doc)}
                    aria-label={`View ${doc.originalName}`}
                    className="focus-ring grid h-9 w-9 shrink-0 place-items-center rounded-full text-stone transition-colors hover:bg-white hover:text-ink"
                  >
                    <Eye className="h-4 w-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setDeleteTargets([doc.id])}
                    aria-label={`Delete ${doc.originalName}`}
                    className={iconBtnBad}
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              );
            })}
          </div>
        </TooltipProvider>
      )}

      <AlertDialog open={deleteTargets !== null} onOpenChange={(o) => !o && setDeleteTargets(null)}>
        <AlertDialogContent className="dlg-card-plain">
          <AlertDialogHeader>
            <AlertDialogTitle className="font-display text-2xl text-ink">
              {deleteTargets !== null && deleteTargets.length > 1 ? `Delete ${deleteTargets.length} documents?` : "Delete this document?"}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-sm leading-relaxed text-body-gray">
              The file will be permanently removed from your records.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className={cancelBtn}>Keep it</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                if (deleteTargets) void runDelete(deleteTargets);
              }}
              disabled={deleting}
              className={`${ghostBadBtn} px-5 py-2.5`}
            >
              {deleting ? "Deleting…" : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Document preview modal — click a row to view it here (shared component) */}
      <DocumentPreviewModal
        doc={preview}
        open={preview !== null}
        onOpenChange={(o) => {
          if (!o) setPreview(null);
        }}
      />
    </SectionCard>
  );
}
