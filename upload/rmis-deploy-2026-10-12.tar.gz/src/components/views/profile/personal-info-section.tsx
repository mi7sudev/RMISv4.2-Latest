"use client";

// ============================================================================
// RMIS — Profile builder · Section 01 Personal Information (spec §7.4).
// 4 disclosure groups with "X of N completed" micro-labels: Identity,
// Address, Legal Disclosures (conditional detail fields), Character
// References (1–5 rows; empty-name rows filtered at save).
// AUTOSAVE: every change re-arms a 1.2 s debounce → PUT /api/applicant/profile
// with a live save-state indicator; an explicit "Save Changes" button also
// exists (toast + session refresh). birthDate is sent as YYYY-MM-DD directly.
// Task 25: manual "Save Changes" validates required fields and blocks the
// save on gaps; autosave keeps persisting partial drafts as before.
// Bevel pass: white section panel + cloud/60 disclosure groups, quiet save
// indicator; autosave behavior unchanged. BEUI field pass: text fields render
// the official capsule Input (src/components/motion/input) and the case-details
// textarea the BEUI-style glue Textarea (src/components/forms/textarea) — both
// draw their own label, required fields getting a trailing " *"; the Gender /
// Civil Status selects keep the shared Label (selects are out of scope).
// Task 32: the manual-save errors now run the OFFICIAL SignUpForm touched
// timing via useAuthErrors (src/components/forms/field-errors) — rules are
// derived on every render (an error clears the moment its field is fixed),
// a field's rule appears once it is left (onBlur) and Save Changes reveals
// every gap at once; the old error map + re-arm dance is gone. Icon-led
// capsules (User/Mail/Phone) and reserved error lines match the sign-in /
// sign-up look; the Save Changes button runs the official StatefulButton
// loading lifecycle. Autosave behavior untouched (blur/reveal never saves).
// Task 33 — container alignment: the disclosure groups, reference rows and
// select triggers wear the OFFICIAL SignUpForm card/field anatomy via the
// shared ./beui-form tokens — rounded-3xl bordered cards, official field-
// label grammar on the selects, h-11 transparent triggers with the official
// focus/error tokens — while keeping the section's cloud/60 + white/80
// surface colors (the one sanctioned deviation from the auth canvas).
// ============================================================================

import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { toast } from "@/lib/toast";
import { Mail, MapPin, Phone, Plus, Scale, User, UserRound, Users } from "lucide-react";
import { apiFetch } from "@/lib/client";
import { CIVIL_STATUS_OPTIONS } from "@/lib/constants";
import { SectionCard } from "@/components/ui/shell";
import { useAuthErrors } from "@/components/forms/field-errors";
import { StatefulButton } from "@/components/motion/button";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleIndicator,
  CollapsibleTrigger,
} from "@/components/motion/collapsible";
import { Input } from "@/components/motion/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/forms/textarea";
import YesNoField from "./yes-no-field";
import { SaveHint } from "./save-hint";
import {
  BEUI_FIELD_FILL,
  BEUI_FIELD_LABEL,
  BEUI_TRIGGER_BASE,
} from "./beui-form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/motion/select";
import type { ApplicantProfile, CharacterReference } from "./section-types";

// ── Draft model ─────────────────────────────────────────────────────────────

type PersonalForm = {
  firstName: string;
  middleName: string;
  lastName: string;
  extensionName: string;
  emailAddress: string;
  mobileNumber: string;
  contactNumber: string;
  birthDate: string;
  birthPlace: string;
  gender: string;
  civilStatus: string;
  citizenship: string;
  ethnicity: string;
  isPwd: boolean;
  presentAddress: string;
  houseNumber: string;
  street: string;
  subdivision: string;
  barangay: string;
  city: string;
  province: string;
  country: string;
  zipCode: string;
  isGovernment: boolean;
  adminCase: boolean;
  adminCaseDetails: string;
  crimeCharge: boolean;
  crimeDate: string;
  crimeCaseStatus: string;
};

const EMPTY_FORM: PersonalForm = {
  firstName: "", middleName: "", lastName: "", extensionName: "",
  emailAddress: "", mobileNumber: "", contactNumber: "",
  birthDate: "", birthPlace: "", gender: "", civilStatus: "", citizenship: "", ethnicity: "",
  isPwd: false,
  presentAddress: "", houseNumber: "", street: "", subdivision: "", barangay: "",
  city: "", province: "", country: "", zipCode: "",
  isGovernment: false, adminCase: false, adminCaseDetails: "",
  crimeCharge: false, crimeDate: "", crimeCaseStatus: "",
};

const EMPTY_REF: CharacterReference = { name: "", title: "", company: "", companyAddress: "", email: "", contact: "" };

const IDENTITY_FIELDS: (keyof PersonalForm)[] = [
  "firstName", "middleName", "lastName", "extensionName", "emailAddress", "mobileNumber",
  "contactNumber", "birthDate", "birthPlace", "gender", "civilStatus", "citizenship", "ethnicity",
];
const ADDRESS_FIELDS: (keyof PersonalForm)[] = [
  "presentAddress", "houseNumber", "street", "subdivision", "barangay", "city", "province", "country", "zipCode",
];

function seedForm(p: ApplicantProfile | null): PersonalForm {
  if (!p) return { ...EMPTY_FORM };
  return {
    firstName: p.firstName ?? "",
    middleName: p.middleName ?? "",
    lastName: p.lastName ?? "",
    extensionName: p.extensionName ?? "",
    emailAddress: p.emailAddress ?? "",
    mobileNumber: p.mobileNumber ?? "",
    contactNumber: p.contactNumber ?? "",
    birthDate: p.birthDate ?? "",
    birthPlace: p.birthPlace ?? "",
    gender: p.gender ?? "",
    civilStatus: p.civilStatus ?? "",
    citizenship: p.citizenship ?? "",
    ethnicity: p.ethnicity ?? "",
    isPwd: p.isPwd === true,
    presentAddress: p.presentAddress ?? "",
    houseNumber: p.houseNumber ?? "",
    street: p.street ?? "",
    subdivision: p.subdivision ?? "",
    barangay: p.barangay ?? "",
    city: p.city ?? "",
    province: p.province ?? "",
    country: p.country ?? "",
    zipCode: p.zipCode ?? "",
    isGovernment: p.isGovernment === true,
    adminCase: p.adminCase === true,
    adminCaseDetails: p.adminCaseDetails ?? "",
    crimeCharge: p.crimeCharge === true,
    crimeDate: p.crimeDate ?? "",
    crimeCaseStatus: p.crimeCaseStatus ?? "",
  };
}

function filledCount(form: PersonalForm, keys: (keyof PersonalForm)[]): number {
  return keys.filter((k) => typeof form[k] === "string" && (form[k] as string).trim() !== "").length;
}

// ── Small field primitives ──────────────────────────────────────────────────

// Task 33 — official SignUpForm tokens: the select label uses the exact
// field-label grammar the official Input renders; the select trigger uses
// the official field tokens (h-11 capsule height, border-border, white fill
// — visible on the cloud/60 groups — the trigger's corner radius stays the
// official Select's own).
const labelCls = BEUI_FIELD_LABEL;
const inputCls = BEUI_TRIGGER_BASE;
const NONE = "__none__";

function TextField({
  label, required, helper, value, onChange, type = "text", placeholder, error, icon, onBlur,
}: {
  label: string; required?: boolean; helper?: string; value: string;
  onChange: (v: string) => void; type?: string; placeholder?: string; error?: string;
  icon?: ReactNode; onBlur?: () => void;
}) {
  return (
    <div>
      {/* Official BEUI Input renders its own label; required fields get a
          trailing " *" (the official label prop is a plain string). Passing
          `error` arms the official shake + red ring + message; every field
          reserves its error line (auth rhythm). `icon` renders the official
          left-icon capsule; onBlur passthrough drives the Task 32 touch. */}
      <Input
        type={type}
        label={required ? `${label} *` : label}
        value={value}
        placeholder={placeholder}
        error={error}
        reserveErrorLine
        leftIcon={icon}
        classNames={{ field: BEUI_FIELD_FILL }}
        onChange={onChange}
        onBlur={onBlur}
      />
      {helper && <p className="mt-1 text-xs text-body-gray">{helper}</p>}
    </div>
  );
}

function SelectField({
  label, required, helper, value, options, onChange,
}: {
  label: string; required?: boolean; helper?: string; value: string;
  options: string[]; onChange: (v: string) => void;
}) {
  return (
    <div>
      <Label className={labelCls}>
        {label}
        {required && <span className="text-dusty-rose"> *</span>}
      </Label>
      {/* Official BEUI Select on the official field tokens (Task 33) —
          items must carry plain-string children so the trigger label
          registration resolves (span child = raw value shown). */}
      <Select value={value !== "" ? value : NONE} onValueChange={(v) => onChange(v === NONE ? "" : v)}>
        <SelectTrigger className={inputCls}>
          <span className="sr-only">{label}</span>
          <SelectValue placeholder="Select…" />
        </SelectTrigger>
        <SelectContent>
          {options.map((o) => (
            <SelectItem key={o} value={o}>
              {o}
            </SelectItem>
          ))}
          <SelectItem value={NONE} className="text-stone">
            Not specified
          </SelectItem>
        </SelectContent>
      </Select>
      {helper && <p className="mt-1 text-xs text-body-gray">{helper}</p>}
    </div>
  );
}

/** Collapsible disclosure group — icon + title + "X of N" count + chevron,
 *  content in a cloud-tint sub-panel. Compact default: all open. */
function CollapsibleGroup({
  icon: Icon,
  title,
  done,
  total,
  children,
  defaultOpen = true,
}: {
  icon: typeof UserRound;
  title: string;
  done: number;
  total: number;
  children: ReactNode;
  defaultOpen?: boolean;
}) {
  const [open, setOpen] = useState(defaultOpen);
  // Task 33 — the group is a SignUpForm-shaped card: rounded-3xl bordered,
  // cloud/60 surface preserved.
  return (
    <Collapsible open={open} onOpenChange={setOpen} className="rounded-3xl border border-border bg-cloud/60">
      <CollapsibleTrigger
        render={<button className="flex min-h-[44px] w-full items-center gap-2.5 p-3.5 text-left transition-colors hover:bg-white/60" />}
      >
        <Icon className="h-4 w-4 shrink-0 text-stone" aria-hidden="true" />
        <span className="min-w-0 flex-1 truncate text-sm font-medium text-ink">{title}</span>
        <span className="shrink-0 rounded-full bg-white/80 px-2.5 py-1 text-xs font-medium text-stone">
          <span className="num">{done}</span>/<span className="num">{total}</span>
        </span>
        <CollapsibleIndicator className="text-stone" />
      </CollapsibleTrigger>
      <CollapsibleContent contentClassName="border-t border-divider p-4">{children}</CollapsibleContent>
    </Collapsible>
  );
}

function RefRow({
  index, reference, onChange, onRemove, canRemove,
}: {
  index: number; reference: CharacterReference; onChange: (patch: Partial<CharacterReference>) => void;
  onRemove: () => void; canRemove: boolean;
}) {
  const fields: { key: keyof CharacterReference; label: string; type?: string }[] = [
    { key: "name", label: "Name" },
    { key: "title", label: "Title / Position" },
    { key: "company", label: "Company" },
    { key: "companyAddress", label: "Company Address" },
    { key: "email", label: "Email", type: "email" },
    { key: "contact", label: "Contact No." },
  ];
  return (
    <div className="rounded-3xl border border-border bg-white/80 p-4">
      <div className="mb-3 flex items-center justify-between">
        <p className="text-xs font-medium text-stone">Reference <span className="num">{index + 1}</span></p>
        <button
          type="button"
          onClick={onRemove}
          disabled={!canRemove}
          className="focus-ring min-h-[44px] px-3 text-xs text-stone underline-offset-4 hover:text-[var(--bad)] hover:underline disabled:opacity-40"
        >
          Remove
        </button>
      </div>
      <div className="grid grid-cols-1 gap-x-3 gap-y-1 sm:grid-cols-2">
        {fields.map((f) => (
          <Input
            key={f.key}
            type={f.type ?? "text"}
            label={f.label}
            value={(reference[f.key] as string | null) ?? ""}
            reserveErrorLine
            onChange={(next) => onChange({ [f.key]: next })}
          />
        ))}
      </div>
    </div>
  );
}

// ── Main section ────────────────────────────────────────────────────────────

export default function PersonalInfoSection({
  profile,
  seed,
  refreshSession,
}: {
  profile: ApplicantProfile | null;
  /** Bump to force a re-seed from the server profile (after PDS auto-apply / clear). */
  seed: number;
  refreshSession: () => Promise<unknown>;
}) {
  const [form, setForm] = useState<PersonalForm>(EMPTY_FORM);
  const [refs, setRefs] = useState<CharacterReference[]>([{ ...EMPTY_REF }]);
  const [saveState, setSaveState] = useState<"idle" | "dirty" | "saving" | "saved" | "error">("idle");
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const formRef = useRef(form);
  const refsRef = useRef(refs);
  const seededToken = useRef<string>("");

  // Keep latest-value refs in sync after commit (never during render).
  useEffect(() => {
    formRef.current = form;
    refsRef.current = refs;
  }, [form, refs]);

  // Seed (and re-seed on `seed` bumps) from the loaded profile — never during
  // silent reloads, so in-flight typing/autosave is never clobbered.
  useEffect(() => {
    if (!profile) return;
    const token = `${seed}`;
    if (seededToken.current === token) return;
    seededToken.current = token;
    setForm(seedForm(profile));
    const list = Array.isArray(profile.characterReferences) ? profile.characterReferences : [];
    setRefs(list.length > 0 ? list.map((r) => ({ ...EMPTY_REF, ...r })) : [{ ...EMPTY_REF }]);
    setSaveState("idle");
  }, [profile, seed]);

  // Task 32 — official SignUpForm timing: rules are derived on EVERY render
  // (an error clears the moment its field is fixed); `shown` reveals a rule
  // only once the field has been left (onBlur) or Save Changes was pressed.
  // Typed over ALL PersonalForm keys (not just the ones with rules) so the
  // blur touch covers every field in the section.
  const rules: Partial<Record<keyof PersonalForm, string>> = {
    firstName: form.firstName.trim() === "" ? "First Name is required." : undefined,
    lastName: form.lastName.trim() === "" ? "Last Name is required." : undefined,
    emailAddress: form.emailAddress.trim() === "" ? "Email Address is required." : undefined,
    ...(form.adminCase && form.adminCaseDetails.trim() === ""
      ? { adminCaseDetails: "Describe the administrative case to continue." }
      : {}),
  };
  const { shown, touch, touchAll, hasGaps } = useAuthErrors(rules);

  const save = useCallback(
    async (manual: boolean) => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
        timerRef.current = null;
      }
      setSaveState("saving");
      try {
        const payload: Record<string, string | boolean | CharacterReference[]> = {
          ...formRef.current,
          characterReferences: refsRef.current
            .map((r) => ({
              name: (r.name ?? "").trim(),
              title: (r.title ?? "").trim(),
              company: (r.company ?? "").trim(),
              companyAddress: (r.companyAddress ?? "").trim(),
              email: (r.email ?? "").trim(),
              contact: (r.contact ?? "").trim(),
            }))
            .filter((r) => r.name !== ""), // empty-name rows filtered at save (§7.4)
        };
        await apiFetch("/api/applicant/profile", { method: "PUT", body: payload });
        setSaveState("saved");
        if (manual) {
          toast.success("Profile changes saved");
          await refreshSession();
        }
      } catch (e) {
        setSaveState("error");
        if (manual) toast.error(e instanceof Error ? e.message : "Save failed. Please try again");
      }
    },
    [refreshSession]
  );

  /** Re-arm the 1.2 s autosave debounce on every change (§7.4). Never
   *  triggered by the Task 32 error touch — only real edits save. */
  const armAutosave = useCallback(() => {
    setSaveState("dirty");
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => {
      timerRef.current = null;
      void save(false);
    }, 1200);
  }, [save]);

  useEffect(
    () => () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    },
    []
  );

  const set = useCallback(
    <K extends keyof PersonalForm>(key: K, value: PersonalForm[K]) => {
      setForm((prev) => ({ ...prev, [key]: value }));
      armAutosave();
    },
    [armAutosave]
  );

  /** Manual save — Task 32 official SignUpForm timing: Save Changes reveals
   *  every gap at once (touchAll) and the save only proceeds when the live
   *  rules are clean; correcting a field clears its rule instantly. */
  const saveManual = useCallback(() => {
    touchAll();
    if (hasGaps) return;
    void save(true);
  }, [touchAll, hasGaps, save]);

  const identityDone = filledCount(form, IDENTITY_FIELDS);
  const addressDone = filledCount(form, ADDRESS_FIELDS);
  const legalTotal = 2 + (form.adminCase ? 1 : 0) + (form.crimeCharge ? 2 : 0);
  const legalDone =
    2 +
    (form.adminCase && form.adminCaseDetails.trim() !== "" ? 1 : 0) +
    (form.crimeCharge && form.crimeDate.trim() !== "" ? 1 : 0) +
    (form.crimeCharge && form.crimeCaseStatus.trim() !== "" ? 1 : 0);
  const refsNamed = refs.filter((r) => (r.name ?? "").trim() !== "").length;

  return (
    <SectionCard
      variant="plain"
      icon={UserRound}
      chipTone="slate"
      title="Personal Information"
      description="Your identity, contact details, and legal declarations."
      actions={
        <div className="flex items-center gap-3">
          <SaveHint
            saving={saveState === "saving"}
            saved={saveState === "saved"}
            dirty={saveState === "dirty"}
            error={saveState === "error" ? "Save failed. Click Save Changes" : undefined}
          />
          <StatefulButton
            type="button"
            onClick={saveManual}
            state={saveState === "saving" ? "loading" : "idle"}
            loadingText="Saving"
            className="min-h-[44px] px-5 py-2.5 text-sm"
          >
            Save Changes
          </StatefulButton>
        </div>
      }
    >
      <div className="space-y-3">
        {/* Group 1 — Identity */}
        <CollapsibleGroup icon={UserRound} title="Identity" done={identityDone} total={IDENTITY_FIELDS.length}>
          <div className="grid grid-cols-1 gap-x-3 gap-y-1 sm:grid-cols-2">
            <TextField label="First Name" required placeholder="e.g. Juan" icon={<User />} value={form.firstName} error={shown("firstName")} onChange={(v) => set("firstName", v)} onBlur={() => touch("firstName")} />
            <TextField label="Middle Name" icon={<User />} value={form.middleName} onChange={(v) => set("middleName", v)} onBlur={() => touch("middleName")} />
            <TextField label="Last Name" required placeholder="e.g. Dela Cruz" icon={<User />} value={form.lastName} error={shown("lastName")} onChange={(v) => set("lastName", v)} onBlur={() => touch("lastName")} />
            <TextField
              label="Extension Name"
              helper="e.g. Jr., Sr., III"
              icon={<User />}
              value={form.extensionName}
              onChange={(v) => set("extensionName", v)}
              onBlur={() => touch("extensionName")}
            />
            <TextField
              label="Email Address"
              required
              type="email"
              helper="Interview invites are sent to this address"
              icon={<Mail />}
              value={form.emailAddress}
              error={shown("emailAddress")}
              onChange={(v) => set("emailAddress", v)}
              onBlur={() => touch("emailAddress")}
            />
            <TextField
              label="Mobile Number"
              type="tel"
              helper="09XXXXXXXXX"
              icon={<Phone />}
              value={form.mobileNumber}
              onChange={(v) => set("mobileNumber", v)}
              onBlur={() => touch("mobileNumber")}
            />
            <TextField label="Secondary Contact No." type="tel" icon={<Phone />} value={form.contactNumber} onChange={(v) => set("contactNumber", v)} onBlur={() => touch("contactNumber")} />
            <TextField label="Birth Date" type="date" value={form.birthDate} onChange={(v) => set("birthDate", v)} onBlur={() => touch("birthDate")} />
            <TextField label="Birth Place" value={form.birthPlace} onChange={(v) => set("birthPlace", v)} onBlur={() => touch("birthPlace")} />
            <SelectField label="Gender" value={form.gender} options={["Male", "Female"]} onChange={(v) => set("gender", v)} />
            <SelectField
              label="Civil Status"
              value={form.civilStatus}
              options={CIVIL_STATUS_OPTIONS}
              onChange={(v) => set("civilStatus", v)}
            />
            <TextField label="Citizenship" value={form.citizenship} onChange={(v) => set("citizenship", v)} onBlur={() => touch("citizenship")} placeholder="Filipino" />
            <TextField label="Ethnicity" value={form.ethnicity} onChange={(v) => set("ethnicity", v)} onBlur={() => touch("ethnicity")} />
            <YesNoField label="Person with Disability (PWD)" value={form.isPwd} onChange={(v) => set("isPwd", v)} />
          </div>
        </CollapsibleGroup>

        {/* Group 2 — Address */}
        <CollapsibleGroup icon={MapPin} title="Address" done={addressDone} total={ADDRESS_FIELDS.length}>
          <div className="grid grid-cols-1 gap-x-3 gap-y-1 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <TextField label="Present Address (full)" value={form.presentAddress} onChange={(v) => set("presentAddress", v)} onBlur={() => touch("presentAddress")} />
            </div>
            <TextField label="House Number" value={form.houseNumber} onChange={(v) => set("houseNumber", v)} onBlur={() => touch("houseNumber")} />
            <TextField label="Street" value={form.street} onChange={(v) => set("street", v)} onBlur={() => touch("street")} />
            <TextField label="Subdivision / Village" value={form.subdivision} onChange={(v) => set("subdivision", v)} onBlur={() => touch("subdivision")} />
            <TextField label="Barangay" value={form.barangay} onChange={(v) => set("barangay", v)} onBlur={() => touch("barangay")} />
            <TextField label="City / Municipality" value={form.city} onChange={(v) => set("city", v)} onBlur={() => touch("city")} />
            <TextField label="Province" value={form.province} onChange={(v) => set("province", v)} onBlur={() => touch("province")} />
            <TextField label="Country" value={form.country} onChange={(v) => set("country", v)} onBlur={() => touch("country")} />
            <TextField label="ZIP Code" value={form.zipCode} onChange={(v) => set("zipCode", v)} onBlur={() => touch("zipCode")} />
          </div>
        </CollapsibleGroup>

        {/* Group 3 — Legal Disclosures */}
        <CollapsibleGroup icon={Scale} title="Legal Disclosures" done={legalDone} total={legalTotal}>
          <div className="grid grid-cols-1 gap-x-3 gap-y-1 sm:grid-cols-2">
            <YesNoField label="Are you a government employee?" value={form.isGovernment} onChange={(v) => set("isGovernment", v)} />
            <YesNoField label="Have you been administratively charged?" value={form.adminCase} onChange={(v) => set("adminCase", v)} />
            {form.adminCase && (
              <div className="sm:col-span-2">
                <Textarea
                  label="Administrative Case Details *"
                  value={form.adminCaseDetails}
                  onChange={(next) => set("adminCaseDetails", next)}
                  onBlur={() => touch("adminCaseDetails")}
                  error={shown("adminCaseDetails")}
                  reserveErrorLine
                  classNames={{ field: BEUI_FIELD_FILL }}
                  placeholder="Briefly describe the case status and particulars"
                />
              </div>
            )}
            <YesNoField label="Have you ever been charged of any crime?" value={form.crimeCharge} onChange={(v) => set("crimeCharge", v)} />
            {form.crimeCharge && (
              <>
                <TextField label="Date Filed" type="date" value={form.crimeDate} onChange={(v) => set("crimeDate", v)} onBlur={() => touch("crimeDate")} />
                <TextField label="Case Status" value={form.crimeCaseStatus} onChange={(v) => set("crimeCaseStatus", v)} onBlur={() => touch("crimeCaseStatus")} />
              </>
            )}
          </div>
        </CollapsibleGroup>

        {/* Group 4 — Character References */}
        <CollapsibleGroup icon={Users} title="Character References" done={refsNamed} total={5}>
          <div className="space-y-3">
            {refs.map((r, i) => (
              <RefRow
                key={i}
                index={i}
                reference={r}
                canRemove={refs.length > 1}
                onChange={(patch) => {
                  setRefs((prev) => prev.map((row, j) => (j === i ? { ...row, ...patch } : row)));
                  armAutosave();
                }}
                onRemove={() => {
                  if (refs.length <= 1) {
                    toast.info("At least one character reference row is kept");
                    return;
                  }
                  setRefs((prev) => prev.filter((_, j) => j !== i));
                  armAutosave();
                }}
              />
            ))}
          </div>
          <button
            type="button"
            onClick={() => {
              if (refs.length >= 5) {
                toast.info("You can add up to 5 character references");
                return;
              }
              setRefs((prev) => [...prev, { ...EMPTY_REF }]);
              armAutosave();
            }}
            className="dlg-ghost mt-3 inline-flex min-h-[44px] w-full items-center justify-center gap-2 py-2.5 text-sm sm:w-auto sm:px-6"
          >
            <Plus className="h-4 w-4" /> Add Character Reference
          </button>
        </CollapsibleGroup>
      </div>
    </SectionCard>
  );
}
